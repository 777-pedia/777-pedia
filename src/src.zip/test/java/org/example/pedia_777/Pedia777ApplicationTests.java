package org.example.pedia_777;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pedia777ApplicationTests {

    @Test
    void contextLoads() {
    }

}
