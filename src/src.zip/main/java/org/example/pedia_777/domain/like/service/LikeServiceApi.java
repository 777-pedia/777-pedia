package org.example.pedia_777.domain.like.service;

public interface LikeServiceApi {
}
