package org.example.pedia_777.domain.review.entity;

public enum ReviewSort {
    LIKES,
    NEWEST,
    OLDEST
}
