package org.example.pedia_777.common.util;

import org.example.pedia_777.common.code.Code;
import org.example.pedia_777.common.dto.GlobalApiResponse;
import org.springframework.http.ResponseEntity;

public class ResponseHelper {
    public static <T> ResponseEntity<GlobalApiResponse<T>> success(Code code, T data) {
        return ResponseEntity
                .status(code.getHttpStatus())
                .body(GlobalApiResponse.success(code, data));
    }

    public static ResponseEntity<GlobalApiResponse<Void>> success(Code code) {
        return ResponseEntity
                .status(code.getHttpStatus())
                .body(GlobalApiResponse.success(code));
    }

    public static ResponseEntity<GlobalApiResponse<Void>> error(Code code) {
        return ResponseEntity
                .status(code.getHttpStatus())
                .body(GlobalApiResponse.error(code));
    }

    public static ResponseEntity<GlobalApiResponse<Void>> error(Code code, String customMessage) {
        return ResponseEntity
                .status(code.getHttpStatus())
                .body(GlobalApiResponse.error(code, customMessage));
    }
}
