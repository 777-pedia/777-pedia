package org.example.pedia_777;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pedia777Application {

    public static void main(String[] args) {
        SpringApplication.run(Pedia777Application.class, args);
    }

}
